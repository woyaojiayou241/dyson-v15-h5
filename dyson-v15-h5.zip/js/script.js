function buyNow() {
    alert('跳转至拼多多购买页面！');
    window.open('https://www.pinduoduo.com', '_blank');
}
